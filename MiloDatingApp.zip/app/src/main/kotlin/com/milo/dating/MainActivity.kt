package com.milo.dating

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Profile(
    val name: String,
    val age: Int,
    val city: String,
    val bio: String,
    val emoji: String
)

private val profiles = listOf(
    Profile("Aarohi", 24, "Jaipur", "Coffee, travel & good conversations ☕", "🌸"),
    Profile("Riya", 23, "Jaipur", "Books, sunsets and street food ✨", "🌅"),
    Profile("Ananya", 25, "Ajmer", "Looking for something genuine 💕", "🌻"),
    Profile("Meera", 22, "Kota", "Music lover • Weekend explorer 🎶", "🎧")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiloApp() }
    }
}

@Composable
fun MiloApp() {
    var selected by remember { mutableIntStateOf(0) }
    var index by remember { mutableIntStateOf(0) }
    var liked by remember { mutableIntStateOf(0) }
    var showMatch by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFE83E6F),
            secondary = Color(0xFFFF7A59),
            background = Color(0xFFFFF8FA)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFFFFF8FA),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selected == 0,
                        onClick = { selected = 0 },
                        icon = { Icon(Icons.Default.Favorite, null) },
                        label = { Text("Discover") }
                    )
                    NavigationBarItem(
                        selected = selected == 1,
                        onClick = { selected = 1 },
                        icon = { Icon(Icons.Default.FavoriteBorder, null) },
                        label = { Text("Matches") }
                    )
                    NavigationBarItem(
                        selected = selected == 2,
                        onClick = { selected = 2 },
                        icon = { Icon(Icons.Default.Person, null) },
                        label = { Text("Profile") }
                    )
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (selected) {
                    0 -> DiscoverScreen(
                        profile = profiles[index % profiles.size],
                        onLike = {
                            liked++
                            showMatch = liked % 2 == 0
                            index++
                        },
                        onPass = { index++ }
                    )
                    1 -> MatchesScreen(liked)
                    else -> ProfileScreen()
                }
                if (showMatch) {
                    MatchDialog(onDismiss = { showMatch = false })
                }
            }
        }
    }
}

@Composable
fun DiscoverScreen(profile: Profile, onLike: () -> Unit, onPass: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Milo", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE83E6F))
            IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Notifications") }
        }

        Spacer(Modifier.height(12.dp))

        Card(
            Modifier.fillMaxWidth().weight(1f),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().weight(1f).background(Color(0xFFFFE1EA)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(profile.emoji, fontSize = 100.sp)
                }
                Column(Modifier.padding(20.dp)) {
                    Text("${profile.name}, ${profile.age}", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("📍 ${profile.city}", color = Color.Gray, fontSize = 15.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(profile.bio, fontSize = 16.sp)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SmallAction(Icons.Default.Close, "Pass", onPass, Color(0xFFE85D75))
            SmallAction(Icons.Default.Favorite, "Like", onLike, Color(0xFFE83E6F), large = true)
            SmallAction(Icons.Default.Star, "Super", {}, Color(0xFFFFB300))
        }
    }
}

@Composable
fun SmallAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    action: () -> Unit,
    color: Color,
    large: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(
            onClick = action,
            modifier = Modifier.size(if (large) 72.dp else 58.dp),
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = color,
                contentColor = Color.White
            )
        ) { Icon(icon, label, modifier = Modifier.size(if (large) 34.dp else 26.dp)) }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun MatchesScreen(likes: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Your Matches", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("$likes likes sent", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        if (likes == 0) {
            Text(
                "No matches yet.\nKeep discovering people you like! 💕",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = Color.Gray
            )
        } else {
            Text("Potential matches", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            profiles.take(minOf(likes, profiles.size)).forEach {
                ListItem(
                    headlineContent = { Text("${it.name}, ${it.age}") },
                    supportingContent = { Text("📍 ${it.city}") },
                    leadingContent = {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Color(0xFFFFE1EA)),
                            contentAlignment = Alignment.Center
                        ) { Text(it.emoji, fontSize = 28.sp) }
                    }
                )
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("My Profile", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(30.dp))
        Box(
            Modifier.size(110.dp).clip(CircleShape).background(Color(0xFFFFE1EA)),
            contentAlignment = Alignment.Center
        ) { Text("😊", fontSize = 56.sp) }
        Spacer(Modifier.height(16.dp))
        Text("Your Name", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Jaipur", color = Color.Gray)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = {}) { Text("Edit Profile") }
    }
}

@Composable
fun MatchDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("It's a Match! 💕", fontWeight = FontWeight.Bold) },
        text = { Text("You both liked each other. Chat functionality will be connected next.") },
        confirmButton = { Button(onClick = onDismiss) { Text("Nice!") } }
    )
}
