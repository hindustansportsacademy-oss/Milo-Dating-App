# Milo Dating App ❤️

A starter Android dating app built with Kotlin + Jetpack Compose.

## Current features
- Discover profiles
- Like / Pass / Super buttons
- Matches screen
- Basic profile screen
- Local demo profile data
- "It's a Match" demo dialog
- GitHub Actions workflow that builds a debug APK

## Next development
Connect authentication, database, image upload, real matching logic, and real-time chat.
