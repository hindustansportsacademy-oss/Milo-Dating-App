import 'package:flutter_test/flutter_test.dart';
import 'package:milo_dating_app/main.dart';

void main() {
  testWidgets('Milo app loads', (tester) async {
    await tester.pumpWidget(const MiloApp());
    expect(find.text('milo'), findsOneWidget);
    expect(find.text('Find someone who feels right.'), findsOneWidget);
  });
}
