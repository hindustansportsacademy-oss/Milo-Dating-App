import 'package:flutter/material.dart';

void main() {
  runApp(const MiloApp());
}

class MiloApp extends StatelessWidget {
  const MiloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Milo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF4F7B),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFFFF8FA),
      ),
      home: const MiloHome(),
    );
  }
}

class Profile {
  final String name;
  final int age;
  final String city;
  final String bio;
  final String emoji;
  final List<String> interests;

  const Profile({
    required this.name,
    required this.age,
    required this.city,
    required this.bio,
    required this.emoji,
    required this.interests,
  });
}

const profiles = [
  Profile(
    name: 'Ananya',
    age: 24,
    city: 'Jaipur',
    bio: 'Coffee, travel and good conversations ☕✨',
    emoji: '👩🏻',
    interests: ['Travel', 'Coffee', 'Music'],
  ),
  Profile(
    name: 'Riya',
    age: 23,
    city: 'Jaipur',
    bio: 'Looking for someone genuine and fun 🌸',
    emoji: '👩🏽',
    interests: ['Movies', 'Food', 'Dance'],
  ),
  Profile(
    name: 'Meera',
    age: 25,
    city: 'Ajmer',
    bio: 'Books, sunsets and weekend trips 🌅',
    emoji: '👩🏻‍🦱',
    interests: ['Books', 'Travel', 'Nature'],
  ),
];

class MiloHome extends StatefulWidget {
  const MiloHome({super.key});

  @override
  State<MiloHome> createState() => _MiloHomeState();
}

class _MiloHomeState extends State<MiloHome> {
  int currentIndex = 0;
  int profileIndex = 0;
  final liked = <String>[];
  final matched = <String>[];

  void pass() {
    setState(() {
      profileIndex = (profileIndex + 1) % profiles.length;
    });
  }

  void like() {
    final profile = profiles[profileIndex];
    setState(() {
      if (!liked.contains(profile.name)) liked.add(profile.name);
      if (!matched.contains(profile.name)) matched.add(profile.name);
      profileIndex = (profileIndex + 1) % profiles.length;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("It's a match with ${profile.name}! 💕")),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _discoverPage(),
      _likesPage(),
      _matchesPage(),
      _profilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[currentIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (index) =>
            setState(() => currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Discover'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Likes'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Matches'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _discoverPage() {
    final p = profiles[profileIndex];
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('milo', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.tune_rounded),
              ),
            ],
          ),
          const Text('Find someone who feels right.', style: TextStyle(fontSize: 16, color: Colors.black54)),
          const SizedBox(height: 14),
          Expanded(
            child: Card(
              clipBehavior: Clip.antiAlias,
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFFFFD6E0), Color(0xFFFFA8BE)],
                        ),
                      ),
                      child: Center(
                        child: Text(p.emoji, style: const TextStyle(fontSize: 120)),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${p.name}, ${p.age}', style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.location_on_outlined, size: 18),
                          const SizedBox(width: 4),
                          Text(p.city, style: const TextStyle(fontSize: 15)),
                        ]),
                        const SizedBox(height: 8),
                        Text(p.bio, style: const TextStyle(fontSize: 15)),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 7,
                          runSpacing: 6,
                          children: p.interests.map((x) => Chip(label: Text(x))).toList(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _roundButton(Icons.close_rounded, pass, 58),
              _roundButton(Icons.favorite_rounded, like, 70),
              _roundButton(Icons.star_rounded, like, 58),
            ],
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _roundButton(IconData icon, VoidCallback onTap, double size) {
    return Material(
      color: Colors.white,
      elevation: 3,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: size,
          height: size,
          child: Icon(icon, size: size * .42, color: const Color(0xFFFF4F7B)),
        ),
      ),
    );
  }

  Widget _likesPage() => _simpleListPage(
        title: 'Your Likes',
        subtitle: '${liked.length} people you liked',
        items: liked.isEmpty ? ['No likes yet'] : liked,
        icon: Icons.favorite_rounded,
      );

  Widget _matchesPage() => _simpleListPage(
        title: 'Matches',
        subtitle: 'Start a conversation',
        items: matched.isEmpty ? ['No matches yet'] : matched,
        icon: Icons.chat_bubble_rounded,
      );

  Widget _simpleListPage({
    required String title,
    required String subtitle,
    required List<String> items,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 20),
          Expanded(
            child: ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) => Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: const Color(0xFFFFD6E0),
                    child: Icon(icon, color: const Color(0xFFFF4F7B)),
                  ),
                  title: Text(items[i], style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: items[i].startsWith('No ') ? const Text('Keep discovering ✨') : const Text('Tap to open chat'),
                  trailing: const Icon(Icons.chevron_right),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _profilePage() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: ListView(
        children: [
          const Text('My Profile', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          const CircleAvatar(
            radius: 62,
            backgroundColor: Color(0xFFFFD6E0),
            child: Text('👨🏻', style: TextStyle(fontSize: 70)),
          ),
          const SizedBox(height: 14),
          const Center(child: Text('Your Name, 25', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800))),
          const Center(child: Text('Jaipur, Rajasthan', style: TextStyle(color: Colors.black54))),
          const SizedBox(height: 22),
          _profileTile(Icons.edit_outlined, 'Edit profile'),
          _profileTile(Icons.workspace_premium_outlined, 'Milo Premium'),
          _profileTile(Icons.shield_outlined, 'Safety & privacy'),
          _profileTile(Icons.settings_outlined, 'Settings'),
        ],
      ),
    );
  }

  Widget _profileTile(IconData icon, String title) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFFFF4F7B)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {},
      ),
    );
  }
}
