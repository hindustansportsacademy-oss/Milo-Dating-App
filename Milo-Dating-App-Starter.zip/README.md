# Milo Dating App

Milo is a Flutter dating-app starter project for Android.

## Current starter features
- Discover profile cards
- Pass / Like / Super-like style buttons
- Likes screen
- Matches screen
- Profile screen
- Bottom navigation
- Modern Material 3 UI

## Next development steps
1. Add Firebase Authentication
2. Add Firestore profiles, likes, matches and messages
3. Add image upload
4. Add real-time chat
5. Add block/report/unmatch
6. Add notifications
7. Add Google Play Billing for premium

This project intentionally starts with local demo data so it can be tested before connecting a backend.
